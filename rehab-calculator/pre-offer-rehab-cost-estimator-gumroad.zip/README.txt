Pre-Offer Rehab Cost Estimator

Open index.html to use the calculator locally, or use the live website link provided on the Gumroad product page.

What this tool does:
- Estimates rehab scope before making an offer
- Uses NAHB 2024 construction cost data as the national baseline
- Adjusts estimates with BLS OEWS local construction labor market multipliers
- Supports state/county market selection, manual multiplier overrides, condition tiers, item overrides, and contingency buffers

Important:
This calculator is an educational pre-offer screening tool. It is not a contractor bid, appraisal, inspection, financial advice, legal advice, or a guarantee of actual repair costs.
